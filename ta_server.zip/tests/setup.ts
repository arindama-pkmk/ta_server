import 'reflect-metadata'; // Required for Inversify to work correctly

// You can add global mock setup here if needed (e.g., database mock)
